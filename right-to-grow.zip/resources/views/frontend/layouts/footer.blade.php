<footer style="position: fixed; bottom: 0; width: 100%">
    <div class="text-center p-4" style="background-color: #5314b1; color:white">
        © {{ date("Y") }} Copyright:
        <a class="text-reset fw-bold" href="#">right2grow.com</a>
    </div>
</footer>
