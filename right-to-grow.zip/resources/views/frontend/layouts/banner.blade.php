<div class="banner ptb-100">
    <div class="container-fluid container-large">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="banner-text-area banner-text-area-3">
                    <h6>Right 2 Grow Project Consortium, Bangladesh</h6>
                    <h1>Right 2 Grow</h1>
                    <p>
                        Vivamus suscipit tortor eget felis porttitor volutpat. Proin eget tortor risus.
                        Sed porttitor lectus nibh. Vivamus suscipit tortor eget felis porttitor volutpat.

                        Cras ultricies ligula sed magna dictum porta. Nulla quis lorem ut libero malesuada feugiat.
                        Proin eget tortor risus.
                        Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula.
                        Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Cras ultricies ligula sed magna dictum porta.
                    </p>
{{--                    <a class="default-button" href="#"><span>Register Now</span></a>--}}
                </div>
            </div>
            <div class="col-lg-6">
                <div class="banner-img-3">
                    <img src="{{asset('assets/frontend/images/banner/banner-bg.jpeg')}}" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
