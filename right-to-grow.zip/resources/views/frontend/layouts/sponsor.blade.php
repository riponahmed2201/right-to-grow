<div class="row">
    <div class="col mt-5">
        <div class="wrapme">
            <section class="customer-logos slider">
                <div class="slide">
                    <img src="{{asset('assets/frontend/assets/images/partners/ACF-Eng_Col.jpg')}}" alt="test" width="175px" height="100px">
                </div>
                <div class="slide">
                    <img src="{{asset('assets/frontend/assets/images/partners/CEGAA_FNL.jpg')}}" alt="test" width="175px" height="100px">
                </div>
                <div class="slide">
                    <img src="{{asset('assets/frontend/assets/images/partners/hlp.jpg')}}" alt="test" width="175px" height="100px">
                </div>
                <div class="slide">
                    <img src="{{asset('assets/frontend/assets/images/partners/JN.jpg')}}" alt="test" width="150px" height="100px">
                </div>
                <div class="slide">
                    <img src="{{asset('assets/frontend/assets/images/partners/max.jpg')}}" alt="test" width="175px" height="100px">
                </div>
                <div class="slide">
                    <img src="{{asset('assets/frontend/assets/images/partners/save-the-child.jpg')}}" alt="test" width="175px" height="100px">
                </div>
                <div class="slide">
                    <img src="{{asset('assets/frontend/assets/images/partners/sda.jpg')}}" alt="test" width="175px" height="100px">
                </div>
                <div class="slide">
                    <img src="{{asset('assets/frontend/assets/images/partners/hunger.jpg')}}" alt="test" width="175px" height="100px">
                </div>
                <div class="slide">
                    <img src="{{asset('assets/frontend/assets/images/partners/world-vision.jpg')}}" alt="test" width="175px" height="100px">
                </div>
            </section>
        </div>
    </div>
</div>
