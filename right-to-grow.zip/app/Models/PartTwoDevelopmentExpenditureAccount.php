<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PartTwoDevelopmentExpenditureAccount extends Model
{
    use HasFactory;

    protected $table = 'part_two_development_expenditure_accounts';
}
