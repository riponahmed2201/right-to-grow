<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PartTwoDevelopmentExpenditureChildCategoryAccount extends Model
{
    use HasFactory;

    protected $table = 'part_two_development_expenditure_child_category_accounts';
}
